# Compiler Design Visualizer

## Project Status, Architecture, and Roadmap

## 1. Project Summary

Compiler Design Visualizer is a browser-based educational compiler workbench. It exposes the major stages of a compilation pipeline instead of showing only source code and final output.

The core phases are:

1. Lexical analysis
2. Syntax analysis
3. Semantic analysis
4. Intermediate code generation
5. Optimization
6. Target code generation

The project currently combines three layers:

- Tree-sitter for syntax validation and syntax-tree generation.
- Existing language-specific educational parsers and lowering modules for supported subsets.
- Generic Tree-sitter-backed fallback output for valid syntax that is outside a language-specific lowering subset.

The fallback is intentionally educational. It must not be presented as a real typed IR or machine-code compiler backend.

## 2. Current Product Position

The project is an academic visualizer, not a complete compiler suite. It can demonstrate real transformations for supported examples and can inspect broader source files through Tree-sitter.

Current capabilities:

- Browser-based source editing.
- Example loading for multiple languages.
- Source upload for supported file extensions.
- Incremental six-phase pipeline animation.
- Syntax validation through Tree-sitter for C, C++, Java, Python, JavaScript, and TypeScript.
- Existing SQL parser path remains separate because the installed SQL grammar does not currently provide a browser WASM artifact.
- AST visualization with zoom, pan, node inspection, and collapse controls.
- Token tables, symbol tables, TAC views, optimization comparison, CFG views, and target output views.
- Diagnostics with phase, line, and column information.
- Reproducible browser bundling through esbuild.

Current limitations:

- Tree-sitter does not provide semantic analysis, type checking, TAC, optimization, or machine code by itself.
- The existing language-specific backends support educational subsets, not arbitrary modern source files.
- Generic Tree-sitter fallback output is a node trace, not genuine language-specific TAC or machine code.
- Full arbitrary-source output requires real compiler backends such as Clang/LLVM, javac, Python bytecode tooling, JavaScript tooling, and a SQL planner.
- SQL does not yet use the shared browser Tree-sitter path.
- Opening the application directly with `file://` is not reliable for WASM loading. Use the local server.

## 3. Runtime Architecture

```text
index.html
  |
  +-- css/style.css
  +-- js/bundle.js
        |
        +-- js/main.js
              |
              +-- language selector and editor state
              +-- PipelineStrip
              +-- PhaseFeed
              +-- runPipeline
                    |
                    +-- lexical phase
                    +-- Tree-sitter syntax validation
                    +-- language-specific AST lowering when supported
                    +-- generic Tree-sitter fallback when lowering is unsupported
                    +-- semantic analysis
                    +-- intermediate representation
                    +-- optimization
                    +-- target output
```

### 3.1 Browser entry point

[index.html](index.html) is the primary current entry point. It loads the stylesheet and the generated browser bundle.

[Compiler Design Visualizer.html](Compiler%20Design%20Visualizer.html) is an older standalone fixture-backed page with inline CSS and inline JavaScript. It is not the primary modular application path and should either be archived, clearly labeled as legacy, or removed after confirming it is no longer used.

### 3.2 Application entry point

[js/main.js](js/main.js) owns application wiring:

- Selects the active language.
- Loads examples.
- Connects editor callbacks.
- Starts and stops the pipeline.
- Updates the phase strip and phase feed.
- Disables controls while a run is active.
- Displays final run status.

### 3.3 UI modules

- [js/ui/editor.js](js/ui/editor.js): source editor, line numbers, keyboard behavior, upload, drag and drop, statistics, and error-line highlighting.
- [js/ui/pipeline.js](js/ui/pipeline.js): six-phase status strip.
- [js/ui/feed.js](js/ui/feed.js): phase cards, skeleton states, result updates, and scrolling.
- [js/ui/renderer.js](js/ui/renderer.js): phase-specific result rendering.
- [js/ui/ast-tree.js](js/ui/ast-tree.js): interactive graphical AST.
- [js/ui/cfg.js](js/ui/cfg.js): control-flow graph view.
- [js/ui/animator.js](js/ui/animator.js): TAC step-through visualization.

### 3.4 Core modules

- [js/core/contract.js](js/core/contract.js): result schema, statuses, phase order, and phase names.
- [js/core/errors.js](js/core/errors.js): compiler error hierarchy and diagnostics.
- [js/core/runner.js](js/core/runner.js): asynchronous phase orchestration and error propagation.
- [js/core/tree-sitter.js](js/core/tree-sitter.js): browser Tree-sitter runtime, grammar loading, syntax error detection, and generic AST conversion.
- [js/core/tree-sitter-pipeline.js](js/core/tree-sitter-pipeline.js): generic semantic summary, node-trace IR, trace optimization, and target trace fallback.

## 4. Pipeline Contract

The shared result model is defined in [js/core/contract.js](js/core/contract.js).

Each run contains:

```javascript
{
  (schemaVersion,
    runId,
    mode,
    language,
    sourceHash,
    status,
    phases,
    diagnostics);
}
```

Each phase should expose one of these statuses:

- `pending`: not started.
- `running`: currently being generated.
- `completed`: produced an output.
- `failed`: stopped with a diagnostic.
- `not_run`: intentionally skipped because an earlier phase failed or the backend is unavailable.
- `partial`: reserved for incomplete pipeline results. Current successful Tree-sitter fallback runs are reported as completed with an explanatory note.

A phase output must never claim successful language-specific compilation when it only contains a generic syntax trace.

## 5. Tree-sitter Integration

[tree-sitter.js](js/core/tree-sitter.js) loads:

- `vendor/tree-sitter/web-tree-sitter.wasm`
- `vendor/tree-sitter/tree-sitter-c.wasm`
- `vendor/tree-sitter/tree-sitter-cpp.wasm`
- `vendor/tree-sitter/tree-sitter-java.wasm`
- `vendor/tree-sitter/tree-sitter-python.wasm`
- `vendor/tree-sitter/tree-sitter-javascript.wasm`
- `vendor/tree-sitter/tree-sitter-typescript.wasm`

The syntax flow is:

1. Load or reuse the shared Tree-sitter runtime.
2. Load the grammar for the selected language.
3. Parse the source.
4. Detect `ERROR` and missing nodes.
5. Convert the syntax tree into the project AST shape for visualization.
6. Attempt existing language-specific lowering for supported subsets.
7. Use generic fallback output when valid syntax cannot be lowered by the educational backend.

Tree-sitter should remain the authority for syntax validity. Language-specific parsers may still be used as lowering adapters for supported educational subsets, but they must not override a Tree-sitter syntax failure.

## 6. Language Module Structure

Language modules live under [js/languages](js/languages):

- `c`
- `cpp`
- `java`
- `python`
- `javascript`
- `typescript`
- `sql`

A language module may expose:

```javascript
{
  (id, label, examples, lexer, parser, semantic, ir, optimizer, codegen);
}
```

The current modules are educational backends. They are not guaranteed to process every legal source file for their language.

## 7. Output Modes

### 7.1 Language-specific mode

Used when the existing language lowering can consume the source.

Expected outputs:

- meaningful tokens
- language-specific AST
- symbol table and semantic checks
- TAC or equivalent IR
- optimization comparison
- educational target output or backend output

### 7.2 Generic Tree-sitter mode

Used when Tree-sitter validates the source but the existing lowering cannot represent it.

Expected outputs:

- syntax tree visualization
- declaration summary
- bounded node-trace IR
- trace-level optimization
- generic target trace

This mode is useful for inspection, but it is not a substitute for Clang/LLVM, javac, Python bytecode, or JavaScript runtime backends.

## 8. Real Compiler Backend Roadmap

To produce proper output for arbitrary files, add backend adapters behind one common server API.

### C and C++

Recommended backend:

- Clang frontend for parsing, diagnostics, AST, and semantic analysis.
- LLVM IR for a real intermediate representation.
- LLVM optimization passes.
- LLVM target machine for assembly or object code.

### Java

Recommended backend:

- `javac` for compilation and diagnostics.
- `javap` for JVM bytecode inspection.
- Optional ASM integration for structured bytecode analysis.

### JavaScript and TypeScript

Recommended backend:

- Babel parser or the TypeScript compiler API for AST and diagnostics.
- ESTree or TypeScript AST adapter for semantic inspection.
- V8 bytecode only as a runtime-specific, non-stable output.
- Do not claim stable machine code for JavaScript because it is JIT-dependent.

### Python

Recommended backend:

- Python `ast` for syntax and semantic-like structure.
- `dis` for CPython bytecode.
- Clearly label bytecode as interpreter bytecode, not native machine code.

### SQL

Recommended backend:

- SQLGlot or a database-specific parser.
- Query plan from a selected database engine.
- Label the output as a logical or physical query plan, not machine code.

## 9. Recommended Backend API

Use a local Node.js or Python server between the browser and compiler tools.

```text
POST /api/analyze
```

Request:

```json
{
  "language": "cpp",
  "source": "int main() { return 0; }",
  "options": {
    "target": "x86-64",
    "standard": "c++20"
  }
}
```

Response:

```json
{
  "status": "completed",
  "mode": "clang-llvm",
  "language": "cpp",
  "diagnostics": [],
  "phases": {
    "lexical": {},
    "syntax": {},
    "semantic": {},
    "intermediate": {},
    "optimization": {},
    "target": {}
  }
}
```

Every adapter should normalize its result into the same phase contract. The browser should not need to know how a language was compiled.

## 10. Safety Requirements for Uploaded Files

Do not execute uploaded code directly on the host process.

A real backend must use:

- temporary working directories
- strict execution timeouts
- memory and output-size limits
- disabled network access
- process isolation or containers
- sanitized compiler arguments
- cleanup after every request
- no persistent execution permissions

## 11. Current Progress

### Complete

- Six-phase UI and result model.
- Modular language registry.
- Existing educational compiler implementations.
- Tree-sitter browser runtime and grammars for six languages.
- Tree-sitter syntax diagnostics.
- Generic AST visualization.
- Generic fallback outputs for broad syntax coverage.
- Proper TAC and target output for supported language-specific subsets.
- Error propagation for lexer and parser result errors.
- Responsive layout corrections for long phase output.
- AST viewport and parent-node positioning corrections.
- npm build and local HTTP server commands.
- Backend API and sandbox for C/C++ (Clang/LLVM).

### In progress or incomplete

- Full language-specific lowering for arbitrary source files.
- Real backend integration for C/C++, Java, Python, JavaScript, TypeScript, and SQL.
- Browser-compatible SQL grammar.
- Backend API and sandbox.
- Consistent capability labels across all phases.
- Automated tests for every language and failure mode.
- Retirement of the legacy standalone HTML implementation.

## 12. Immediate Next Steps

1. Keep Tree-sitter as the shared syntax layer.
2. Add explicit capability metadata per language and backend mode.
3. Stop generic output from being labeled as machine code.
4. Build a local `/api/analyze` service.
5. Implement C/C++ through Clang/LLVM first because TAC and machine-code output are central to the project goal.
6. Add Java, Python, JavaScript/TypeScript, and SQL adapters incrementally.
7. Add tests for valid source, syntax errors, semantic errors, unsupported constructs, and uploaded files.
8. Remove or archive the legacy standalone HTML page once the modular app is the only supported entry point.

## 13. Development Commands

Install dependencies:

```powershell
npm install
```

Build the browser bundle:

```powershell
npm run build
```

Start the local server required for WASM assets:

```powershell
npm start
```

Open:

```text
http://localhost:4173/index.html
```
